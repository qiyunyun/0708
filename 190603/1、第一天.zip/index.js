// alert(123)
console.log("珠峰");